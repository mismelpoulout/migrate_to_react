import React from 'react'

export const DashboardPage = () => {
  return (
    <h1>DashboardPage</h1>
  )
}
