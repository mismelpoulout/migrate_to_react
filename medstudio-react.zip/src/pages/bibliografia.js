import UCatolica from "./ucatolica";
import Amir from "./amir";



export default function Bibliografia() {
    return (
        <div className="container">
            <UCatolica />
            <Amir />
        </div>
    );
}