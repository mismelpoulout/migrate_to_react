import React from 'react'

import menu from './icons/menu.svg';
import exit from './icons/exit.svg';
import leftarrow from './icons/leftarrow.svg';
import googleplay from './icons/googleplay.svg';

import './css/loader.css';
import './css/main.css';
import './css/fonts.css';
import './css/header.css';
import './css/sidenav.css';
import './css/footer.css';
import './css/layers.css';
import './css/exam.css';
import './css/videoPlaylist.css';

import Main from './main';

export const HomePage = () => {
  return (
    <div className="container">
      

      <header className="App-header">
        <img src={leftarrow} class="icon btn-closeLayer" id="btn-closeLayer" alt="back" />
        <img src={menu} id="open-sideMenu" class="icon trigger-layer" data-layername="side-nav" alt="menu" />
        <img src={exit} class="icon btn-closeQuiz" id="btn-closeQuiz" alt="back" />
        <h1 class="appName" id="title">Medstudio</h1>
        <button className="btn btn-primary btn-sm ml-auto" onClick={cerrarSesion}>Cerrar Sesión</button>
      </header>
      <br />

      <div className="text-center">

        <br />
        <br />
            <marquee>este registro es solo con fines estadisticos sus datos estan protegidos por google firebase console</marquee>
        <main>
          <Main />
          <br />
          <center>
            <br />
            <section class="container">
              <p>Encuentra nuestra app en Google play</p>
              <a href="https://play.google.com/store/apps/details?id=com.medstudio4all.medstudio">
                <img class="google-play" src={googleplay} />
              </a>
            </section>
          </center>
        </main>
      </div>
    </div>
  );
};
